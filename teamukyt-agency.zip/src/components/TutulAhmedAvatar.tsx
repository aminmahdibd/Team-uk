import React from "react";

interface AvatarProps {
  className?: string;
}

export default function TutulAhmedAvatar({ className = "w-full h-full" }: AvatarProps) {
  return (
    <svg 
      viewBox="0 0 400 400" 
      className={`${className}`}
      xmlns="http://www.w3.org/2000/svg"
      id="tutul-ahmed-avatar"
    >
      <defs>
        <radialGradient id="tutul-bg-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.22" />
          <stop offset="100%" stopColor="#02040a" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="tutul-wings-grad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="50%" stopColor="#eab308" />
          <stop offset="100%" stopColor="#ca8a04" />
        </linearGradient>
        <linearGradient id="tutul-jacket-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#d1d5db" />
          <stop offset="100%" stopColor="#9ca3af" />
        </linearGradient>
        <linearGradient id="tutul-skin-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ecbe99" />
          <stop offset="100%" stopColor="#c58e65" />
        </linearGradient>
        <linearGradient id="tutul-hair-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#222329" />
          <stop offset="100%" stopColor="#0c0d10" />
        </linearGradient>
      </defs>

      {/* Deep London City-Night Midnight Background */}
      <rect width="100%" height="100%" fill="#030611" />
      <circle cx="200" cy="180" r="180" fill="url(#tutul-bg-glow)" />

      {/* Urban Lamppost Structure on the side */}
      <path d="M 68 0 L 76 0 L 76 400 L 68 400 Z" fill="#1e293b" opacity="0.65" />
      <circle cx="72" cy="120" r="8" fill="#e2e8f0" opacity="0.1" />

      {/* Breath-taking Glowing Golden "Angel Wings" (Regent Street style) */}
      <g opacity="0.85">
        {/* Left Wing Loops */}
        <path d="M 125 210 Q 50 110, 85 190 Q 75 220, 115 240 Z" fill="url(#tutul-wings-grad)" opacity="0.4" />
        <path d="M 115 190 Q 20 120, 50 200 Q 60 230, 110 230 C 110 230, 95 180, 115 190 Z" fill="url(#tutul-wings-grad)" />
        <path d="M 140 180 Q 40 70, 90 145 Q 110 160, 135 190 Z" fill="url(#tutul-wings-grad)" opacity="0.6" stroke="#ca8a04" strokeWidth="1" />
        {/* Sparkly wing dots */}
        <circle cx="60" cy="140" r="2.5" fill="#fef08a" />
        <circle cx="85" cy="115" r="1.5" fill="#ffffff" />
        <circle cx="35" cy="170" r="2" fill="#eab308" />

        {/* Right Wing Loops */}
        <path d="M 275 210 Q 350 110, 315 190 Q 325 220, 285 240 Z" fill="url(#tutul-wings-grad)" opacity="0.4" />
        <path d="M 285 190 Q 380 120, 350 200 Q 340 230, 290 230 C 290 230, 305 180, 285 190 Z" fill="url(#tutul-wings-grad)" />
        <path d="M 260 180 Q 360 70, 310 145 Q 290 160, 265 190 Z" fill="url(#tutul-wings-grad)" opacity="0.6" stroke="#ca8a04" strokeWidth="1" />
        {/* Sparkly wing dots */}
        <circle cx="340" cy="140" r="2.5" fill="#fef08a" />
        <circle cx="315" cy="115" r="1.5" fill="#ffffff" />
        <circle cx="365" cy="170" r="2" fill="#eab308" />
      </g>

      {/* Body / Neck */}
      <path d="M 175 212 L 175 275 L 225 275 L 225 212 Z" fill="url(#tutul-skin-grad)" />
      <path d="M 175 212 Q 200 230 225 212 L 225 224 Q 200 242 175 224 Z" fill="#aa714a" opacity="0.65" />

      {/* Dark t-shirt inside */}
      <path d="M 170 268 Q 200 290 230 268 L 230 295 L 170 295 Z" fill="#111827" />

      {/* Stylish Technical Khaki/Grey Bomber Jacket */}
      <path d="M 90 350 C 115 305, 145 280, 200 280 C 255 280, 285 305, 310 350 L 325 400 L 75 400 Z" fill="url(#tutul-jacket-grad)" />
      
      {/* Heavy central black zipper lining */}
      <path d="M 197 292 L 203 292 L 203 400 L 197 400 Z" fill="#1f2937" stroke="#111827" strokeWidth="0.5" />
      {/* Silver metallic zipper detail */}
      <rect x="198" y="302" width="4" height="8" rx="1" fill="#9ca3af" />
      <circle cx="200" cy="316" r="1.5" fill="#e5e7eb" />

      {/* Left/Right Collar Flaps on Bomber Jacket */}
      <path d="M 148 290 L 175 292 L 164 330 L 135 300 Z" fill="#9ca3af" stroke="#6b7280" strokeWidth="1" />
      <path d="M 252 290 L 225 292 L 236 330 L 265 300 Z" fill="#9ca3af" stroke="#6b7280" strokeWidth="1" />

      {/* Stitch lines on shoulders */}
      <path d="M 115 320 Q 140 295, 172 292" fill="none" stroke="#78716c" strokeWidth="1" strokeDasharray="2 2" />
      <path d="M 285 320 Q 260 295, 228 292" fill="none" stroke="#78716c" strokeWidth="1" strokeDasharray="2 2" />

      {/* Head / Face Base */}
      <path d="M 140 150 C 140 92, 260 92, 260 150 C 260 210, 255 238, 200 246 C 145 238, 140 210, 140 150 Z" fill="url(#tutul-skin-grad)" />

      {/* Ears */}
      <circle cx="136" cy="165" r="11" fill="#dba17a" />
      <circle cx="264" cy="165" r="11" fill="#dba17a" />

      {/* Short Razor-Sharp haircut and temple fade */}
      <path d="M 137 142 C 137 110, 160 82, 200 82 C 240 82, 263 110, 263 142 Q 263 115, 235 98 C 215 88, 185 88, 165 98 Q 137 115, 137 142 Z" fill="url(#tutul-hair-grad)" />
      {/* Sideburn sharp lines */}
      <path d="M 137 138 L 139 164 L 143 164 L 140 138 Z" fill="url(#tutul-hair-grad)" />
      <path d="M 263 138 L 261 164 L 257 164 L 260 138 Z" fill="url(#tutul-hair-grad)" />

      {/* Neatly Groomed Beard & Sharp Contours */}
      <path d="M 140 158 C 140 215, 160 246, 200 246 C 240 246, 260 215, 260 158 C 260 206, 248 238, 200 238 C 152 238, 140 206, 140 158 Z" fill="#15171a" opacity="0.95" />
      {/* Mustache */}
      <path d="M 181 197 Q 200 193 219 197 Q 200 203 181 197" fill="#15171a" />
      {/* Soul patch under bottom lip */}
      <path d="M 194 211 L 206 211 L 200 221 Z" fill="#15171a" />

      {/* Sharp Eyebrows */}
      <path d="M 158 136 Q 172 129 185 135" fill="none" stroke="#101114" strokeWidth="4.2" strokeLinecap="round" />
      <path d="M 242 136 Q 228 129 215 135" fill="none" stroke="#101114" strokeWidth="4.2" strokeLinecap="round" />

      {/* Confident, Sparkling Eyes */}
      <ellipse cx="172" cy="147" rx="7.5" ry="4.5" fill="#ffffff" />
      <ellipse cx="228" cy="147" rx="7.5" ry="4.5" fill="#ffffff" />
      <circle cx="172" cy="147" r="4.2" fill="#2d1b10" />
      <circle cx="228" cy="147" r="4.2" fill="#2d1b10" />
      <circle cx="169.5" cy="145" r="1.5" fill="#ffffff" />
      <circle cx="225.5" cy="145" r="1.5" fill="#ffffff" />

      {/* Nose */}
      <path d="M 200 142 L 200 184 Q 200 188 206 186 Q 194 186 200 184" fill="none" stroke="#b07255" strokeWidth="2.5" strokeLinecap="round" />

      {/* Ambitious Smile */}
      <path d="M 183 204 Q 200 213 217 204" fill="none" stroke="#741e1e" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
