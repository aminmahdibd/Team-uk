import React from "react";

interface AvatarProps {
  className?: string;
}

export default function JunedAhmedAvatar({ className = "w-full h-full" }: AvatarProps) {
  return (
    <svg 
      viewBox="0 0 400 400" 
      className={`${className}`}
      xmlns="http://www.w3.org/2000/svg"
      id="juned-ahmed-avatar"
    >
      <defs>
        <radialGradient id="juned-bg-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ef4444" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#050103" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="juned-suit-shade" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1e1e24" />
          <stop offset="100%" stopColor="#111115" />
        </linearGradient>
        <linearGradient id="juned-lapel-shade" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2c2c35" />
          <stop offset="100%" stopColor="#18181f" />
        </linearGradient>
        <linearGradient id="juned-tie-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#991b1b" />
          <stop offset="100%" stopColor="#ec4899" />
        </linearGradient>
        <linearGradient id="juned-skin-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f3c299" />
          <stop offset="100%" stopColor="#c5926b" />
        </linearGradient>
        <linearGradient id="juned-hair-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#111215" />
          <stop offset="100%" stopColor="#050608" />
        </linearGradient>
      </defs>

      {/* Luxury Dark Corporate Background */}
      <rect width="100%" height="100%" fill="#0a0507" />
      <circle cx="200" cy="180" r="180" fill="url(#juned-bg-glow)" />

      {/* Body / Neck */}
      <path d="M 178 210 L 178 275 L 222 275 L 222 210 Z" fill="url(#juned-skin-grad)" />
      {/* Neck Shadow */}
      <path d="M 178 210 Q 200 228 222 210 L 222 225 Q 200 245 178 225 Z" fill="#9d6746" opacity="0.7" />

      {/* Suit Shoulders */}
      <path d="M 80 400 L 95 320 C 110 290, 150 280, 200 280 C 250 280, 290 290, 305 320 L 320 400 Z" fill="url(#juned-suit-shade)" />

      {/* Crisp White Collared Dress Shirt */}
      <path d="M 174 274 L 200 315 L 226 274 L 220 264 L 180 264 Z" fill="#ffffff" />
      <path d="M 176 264 L 195 292 L 182 284 L 174 274 Z" fill="#f4f4f5" />
      <path d="M 224 264 L 205 292 L 218 284 L 226 274 Z" fill="#f4f4f5" />

      {/* Crimson Red/Pink Silk Tie */}
      <path d="M 194 286 L 206 286 L 212 375 L 200 395 L 188 375 Z" fill="url(#juned-tie-grad)" />
      {/* Tie Knot */}
      <path d="M 192 286 L 208 286 L 205 304 L 195 304 Z" fill="#991b1b" stroke="#7f1d1d" strokeWidth="0.5" />
      {/* Tie Dimple/Highlight */}
      <path d="M 199 300 L 201 300 L 202 360 L 198 360 Z" fill="#ec4899" opacity="0.3" />

      {/* Left Lapel */}
      <path d="M 140 280 L 176 335 L 150 400 L 105 400 L 122 320 Z" fill="url(#juned-lapel-shade)" stroke="#1c1917" strokeWidth="1" />
      {/* Right Lapel */}
      <path d="M 260 280 L 224 335 L 250 400 L 295 400 L 278 320 Z" fill="url(#juned-lapel-shade)" stroke="#1c1917" strokeWidth="1" />
      
      {/* Lapel Premium Flower Pin */}
      <circle cx="152" cy="328" r="3" fill="#0891b2" />
      <circle cx="152" cy="328" r="1.5" fill="#a5f3fc" />

      {/* Head & Face Base */}
      <path d="M 140 145 C 140 85, 260 85, 260 145 C 260 205, 255 235, 200 244 C 145 235, 140 205, 140 145 Z" fill="url(#juned-skin-grad)" />

      {/* Ears */}
      <circle cx="136" cy="160" r="13" fill="#dca074" />
      <circle cx="264" cy="160" r="13" fill="#dca074" />
      <circle cx="137" cy="160" r="6" fill="#a06e4a" opacity="0.5" />
      <circle cx="263" cy="160" r="6" fill="#a06e4a" opacity="0.5" />

      {/* Groomed Short Modern Haircut */}
      <path d="M 137 142 C 137 110, 160 80, 200 80 C 240 80, 263 110, 263 142 C 269 135, 267 115, 258 102 C 248 88, 225 83, 200 83 C 175 83, 152 88, 142 102 C 133 115, 131 135, 137 142 Z" fill="url(#juned-hair-grad)" />
      {/* Sideburns */}
      <path d="M 137 140 L 140 165 L 144 165 L 141 140 Z" fill="url(#juned-hair-grad)" />
      <path d="M 263 140 L 260 165 L 256 165 L 259 140 Z" fill="url(#juned-hair-grad)" />

      {/* Eyebrows */}
      <path d="M 158 135 Q 172 127 185 133" fill="none" stroke="#050608" strokeWidth="4.5" strokeLinecap="round" />
      <path d="M 242 135 Q 228 127 215 133" fill="none" stroke="#050608" strokeWidth="4.5" strokeLinecap="round" />

      {/* Eyes */}
      <ellipse cx="172" cy="145" rx="7.5" ry="4.5" fill="#ffffff" />
      <ellipse cx="228" cy="145" rx="7.5" ry="4.5" fill="#ffffff" />
      <circle cx="172" cy="145" r="4" fill="#3f2314" />
      <circle cx="228" cy="145" r="4" fill="#3f2314" />
      <circle cx="170.5" cy="143.5" r="1.5" fill="#ffffff" />
      <circle cx="226.5" cy="143.5" r="1.5" fill="#ffffff" />

      {/* Aesthetic Eyes Details */}
      <path d="M 162 153 Q 172 156 182 153" fill="none" stroke="#9d6746" strokeWidth="1" opacity="0.6" />
      <path d="M 218 153 Q 228 156 238 153" fill="none" stroke="#9d6746" strokeWidth="1" opacity="0.6" />

      {/* Nose */}
      <path d="M 200 140 L 200 182 Q 200 186 205 184 Q 195 184 200 182" fill="none" stroke="#8e5836" strokeWidth="2.5" strokeLinecap="round" />

      {/* Smile */}
      <path d="M 183 203 Q 200 216 217 203" fill="none" stroke="#7a1c1c" strokeWidth="3.5" strokeLinecap="round" />
      <path d="M 186 204 Q 200 210 214 204" fill="none" stroke="#ffffff" strokeWidth="1.2" opacity="0.85" />

      {/* Beard & Mustache */}
      <path d="M 182 195 Q 200 191 218 195 Q 200 200 182 195" fill="#1e2025" opacity="0.8" />
      <path d="M 195 212 L 205 212 L 200 221 Z" fill="#1e2025" opacity="0.8" />
      <path d="M 140 162 C 140 215, 162 244, 200 244 C 238 244, 260 215, 260 162 C 260 206, 248 238, 200 238 C 152 238, 140 206, 140 162 Z" fill="#1e2025" opacity="0.75" />
    </svg>
  );
}
