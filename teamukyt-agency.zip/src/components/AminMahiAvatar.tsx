import React from "react";

interface AvatarProps {
  className?: string;
}

export default function AminMahiAvatar({ className = "w-full h-full" }: AvatarProps) {
  return (
    <svg 
      viewBox="0 0 400 400" 
      className={`${className}`}
      xmlns="http://www.w3.org/2000/svg"
      id="amin-mahi-avatar"
    >
      <defs>
        <radialGradient id="mahi-bg-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.25" />
          <stop offset="100%" stopColor="#040a12" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="mahi-wool-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#a76840" />
          <stop offset="100%" stopColor="#6e3c1d" />
        </linearGradient>
        <linearGradient id="mahi-cap-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#e5c396" />
          <stop offset="100%" stopColor="#b49266" />
        </linearGradient>
        <linearGradient id="mahi-skin-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#edc19e" />
          <stop offset="100%" stopColor="#c5926b" />
        </linearGradient>
        <linearGradient id="mahi-beard-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1e1e24" />
          <stop offset="100%" stopColor="#0c0c0e" />
        </linearGradient>
      </defs>

      {/* Minimal Digital-Studio Grid & Mirror Frame Background */}
      <rect width="100%" height="100%" fill="#03080e" />
      <circle cx="200" cy="200" r="180" fill="url(#mahi-bg-glow)" />

      {/* Isometric/Perspective Mirror lines (Vibe of Mirror Selfie) */}
      <g stroke="#0891b2" strokeWidth="1" opacity="0.12">
        <line x1="80" y1="50" x2="80" y2="350" />
        <line x1="320" y1="50" x2="320" y2="350" />
        <rect x="70" y="40" width="260" height="320" rx="4" fill="none" />
      </g>

      {/* Body / Neck */}
      <path d="M 174 212 L 174 270 L 226 270 L 226 212 Z" fill="url(#mahi-skin-grad)" />
      <path d="M 174 212 Q 200 230 226 212 L 226 225 Q 200 242 174 225 Z" fill="#aa714a" opacity="0.65" />

      {/* White undershirt crew collar */}
      <path d="M 166 264 C 166 264, 185 284, 200 284 C 215 284, 234 264, 234 264 L 236 272 C 236 272, 215 292, 200 292 C 185 292, 164 272, 164 272 Z" fill="#ffffff" stroke="#e4e4e7" strokeWidth="0.5" />

      {/* Thick Knitted Ribbed Brown Wool Sweater */}
      <path d="M 90 350 C 115 305, 145 282, 200 282 C 255 282, 285 305, 310 350 L 325 400 L 75 400 Z" fill="url(#mahi-wool-grad)" />
      
      {/* Heavy ribbed neck trim on sweater */}
      <path d="M 160 278 Q 200 300 240 278 L 244 286 Q 200 310 156 286 Z" fill="#6e3c1d" stroke="#522b14" strokeWidth="1" />

      {/* Knitted Sweater Ribbon Ribbing (High-fidelity details matching user's photo) */}
      <g stroke="#522b14" strokeWidth="1.5" opacity="0.6">
        {/* Repeating rib lines */}
        <line x1="110" y1="365" x2="110" y2="400" />
        <line x1="125" y1="355" x2="125" y2="400" />
        <line x1="140" y1="345" x2="140" y2="400" />
        <line x1="155" y1="335" x2="155" y2="400" />
        <line x1="170" y1="330" x2="170" y2="400" />
        <line x1="185" y1="326" x2="185" y2="400" />
        <line x1="200" y1="325" x2="200" y2="400" />
        <line x1="215" y1="326" x2="215" y2="400" />
        <line x1="230" y1="330" x2="230" y2="400" />
        <line x1="245" y1="335" x2="245" y2="400" />
        <line x1="260" y1="345" x2="260" y2="400" />
        <line x1="275" y1="355" x2="275" y2="400" />
        <line x1="290" y1="365" x2="290" y2="400" />
      </g>

      {/* Polished Silver/Gold Hipster Chain */}
      <path d="M 172 238 Q 200 278 228 238" fill="none" stroke="#cbd5e1" strokeWidth="2.5" opacity="0.9" strokeLinecap="round" />
      <path d="M 172 238 Q 200 278 228 238" fill="none" stroke="#94a3b8" strokeWidth="1" opacity="0.9" strokeDasharray="3 3" />

      {/* Head/Face Base */}
      <path d="M 140 150 C 140 95, 260 95, 260 150 C 260 210, 255 238, 200 246 C 145 238, 140 210, 140 150 Z" fill="url(#mahi-skin-grad)" />

      {/* Ears */}
      <circle cx="136" cy="165" r="12" fill="#daa079" />
      <circle cx="264" cy="165" r="12" fill="#daa079" />

      {/* Groomed Beard */}
      <path d="M 140 158 C 140 215, 160 246, 200 246 C 240 246, 260 215, 260 158 C 260 206, 248 238, 200 238 C 152 238, 140 206, 140 158 Z" fill="url(#mahi-beard-grad)" opacity="0.95" />
      <path d="M 180 196 Q 200 192 220 196 Q 200 203 180 196" fill="url(#mahi-beard-grad)" />
      <path d="M 194 210 L 206 210 L 200 220 Z" fill="url(#mahi-beard-grad)" />

      {/* Visor Hat Brim Shadow on Forehead */}
      <path d="M 142 120 Q 200 135 258 120 Q 200 115 142 120 Z" fill="#1e1b18" opacity="0.45" />

      {/* Tan/Beige Cap (Panel structure) */}
      {/* Cap Dome */}
      <path d="M 141 121 C 141 121, 145 74, 200 74 C 255 74, 259 121, 259 121 Z" fill="url(#mahi-cap-grad)" stroke="#92734a" strokeWidth="1" />
      {/* Panel stitch lines */}
      <path d="M 200 74 Q 200 97 200 121" fill="none" stroke="#a7865c" strokeWidth="1.5" />
      <path d="M 200 74 Q 170 95 142 115" fill="none" stroke="#a7865c" strokeWidth="1.2" />
      <path d="M 200 74 Q 230 95 258 115" fill="none" stroke="#a7865c" strokeWidth="1.2" />
      {/* Top Cap Button */}
      <ellipse cx="200" cy="74" rx="5" ry="3.5" fill="#a78b66" stroke="#8c704a" strokeWidth="0.8" />
      
      {/* Curvaceous visor bill/brim */}
      <path d="M 136 122 Q 200 138 264 122 C 264 122, 256 112, 200 112 C 144 112, 136 122, 136 122 Z" fill="#b49266" stroke="#92734a" strokeWidth="1" />

      {/* Eyebrows */}
      <path d="M 158 138 Q 172 131 185 137" fill="none" stroke="#121315" strokeWidth="4" strokeLinecap="round" />
      <path d="M 242 138 Q 228 131 215 137" fill="none" stroke="#121315" strokeWidth="4" strokeLinecap="round" />

      {/* Focused Eyes */}
      <ellipse cx="172" cy="148" rx="7.5" ry="4.5" fill="#ffffff" />
      <ellipse cx="228" cy="148" rx="7.5" ry="4.5" fill="#ffffff" />
      <circle cx="172" cy="148" r="4.2" fill="#301f15" />
      <circle cx="228" cy="148" r="4.2" fill="#301f15" />
      <circle cx="170" cy="146" r="1.5" fill="#ffffff" />
      <circle cx="226" cy="146" r="1.5" fill="#ffffff" />

      {/* Nose */}
      <path d="M 200 142 L 200 184 Q 200 188 206 186 Q 194 186 200 184" fill="none" stroke="#b07255" strokeWidth="2.5" strokeLinecap="round" />

      {/* Friendly Smart Expression */}
      <path d="M 184 204 Q 200 213 216 204" fill="none" stroke="#7e1a1a" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
